package com.pack.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int c_id,u_id;
	private String u_password,u_dept,u_address;
	private long u_phNo;
	
	
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public String getU_password() {
		return u_password;
	}
	public void setU_password(String u_password) {
		this.u_password = u_password;
	}
	public String getU_dept() {
		return u_dept;
	}
	public void setU_dept(String u_dept) {
		this.u_dept = u_dept;
	}
	public String getU_address() {
		return u_address;
	}
	public void setU_address(String u_address) {
		this.u_address = u_address;
	}
	public long getU_phNo() {
		return u_phNo;
	}
	public void setU_phNo(long u_phNo) {
		this.u_phNo = u_phNo;
	}
	public User(Corporate corporate, int i, String string, String string2, String string3, String string4, long l,
			String string5, String string6, boolean b) {
		
	}
	
	
}
