package com.pack;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.Account;
import com.pack.model.Corporate;
import com.pack.model.Login;
import com.pack.model.User;

import com.pack.service.*;

@Controller
public class CommonController {
	
	@Autowired
	CorporateService corporateservice;
	
	@Autowired
	UserService userservice;
	
	@Autowired
	AccountService accountservice;
	
	@Autowired
	LoginService logservice;
	
	//*******Login Mapping Start************
	
	@RequestMapping("/login") 
	 public String loginForm(Model m) 
	 { 
		 m.addAttribute("log", new Login()); 
		 return "login";  
	 } 
	
	@RequestMapping(value = "/loginCheck", method = RequestMethod.POST)
	public String login(Login log,HttpServletRequest request) {
		
		int uid = log.getU_id();
		String pw = log.getU_password();
		
		System.out.println("Login with id :"+uid+" and password is :"+pw);
		
		boolean isValidLoginId;
		if(uid == 999) {
			isValidLoginId = true;
		}else {
			isValidLoginId = logservice.validateLoginId(uid);
		}
		
		if(isValidLoginId) {
			boolean loginStatus = false;
			
			if(uid == 999) {
				if(pw.equals("@admin")) {
					loginStatus = true;
				}
			}else {
				loginStatus = logservice.loginCheck(log);
			}
			
			if(loginStatus){
				HttpSession session=request.getSession();
				System.out.println("Session Started");
				System.out.println(session.getId());
				session.setAttribute("currentUser", uid);
				if(uid == 999) {
					System.out.println("Admin Login");
					return "boHomepage1"; 
				}else {
					int corId;
					String corName;
					Account user = accountservice.getRecordById(uid);
					corId = user.getC_id();
					Corporate cor = corporateservice.getRecordById(corId);
					corName = cor.getC_name();
					session.setAttribute("corId", corId);
					session.setAttribute("corName", corName);
					
					boolean isFirstLogin = firstLoginCheck(log);
					if(isFirstLogin){
						System.out.println("User First Time Login");
						return "redirect:/resetPasswordForm";
					}else{
						System.out.println("User Login not first time");
						return "foHomepage";
					}
				}
			}else{
				System.out.println("Invalid Credentials");
				return "redirect:/login"; 
			}			
		}else {
			System.out.println("Invalid Credentials"); 
			return "redirect:/login";
		}
	}
	
	protected boolean firstLoginCheck(Login log)  {
		int id = log.getU_id();
		
		Login  login=new Login();
		login = logservice.getRecordById(id);
		int status = login.getIsFirstLogin();
		
		if(status == 1) {
			return true;
		}else {
			return false;
		}
	}
	
	@RequestMapping("/resetPasswordForm") 
	 public String resetForm(Model m) 
	 { 
		 m.addAttribute("log", new Login()); 
		 return "resetPassword";  
	 } 
	
	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public String reset(Login log,HttpServletRequest request) {
		
		HttpSession session=request.getSession(false);
		System.out.println(session.getId());
		int id = (int)session.getAttribute("currentUser");
		String p1 = request.getParameter("u_password");
		log.setU_id(id);
		log.setU_password(p1);
		log.setIsFirstLogin(0);
		
		boolean resetStatus = logservice.update(log);
		
		if(resetStatus) {
			System.out.println("Password Reset Successfully");
			return "redirect:/foHomepage";

		}else {
			System.out.println("Password Reset Failed");
			return "redirect:/resetPasswordForm";
		}
		
	}
	
	@RequestMapping("/logout") 
	public String logout(HttpServletRequest request)  {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		System.out.println(session.getId());
		session.invalidate();
		System.out.println("Session ended");
		return "redirect:/login";
	}
	
	
	
	//*******Login Mapping End**************

	
	@RequestMapping("/boHomepage")  
	public String backOffice()  
	{  
		return "boHomepage";  
	}
	
	@RequestMapping("/boHomepage1")  
	public String backOffice1()  
	{  
		return "boHomepage1";  
	}
	
	@RequestMapping("/corporateSetup") 
	 public String corporateSetup() 
	 { 
		 return "corporateSetup";  
	 } 
	
	@RequestMapping("/userSetup") 
	 public String userSetup() 
	 { 
		 return "userSetup";  
	 } 
	
	@RequestMapping("/accountSetup") 
	 public String accountSetup() 
	 { 
		 return "accountSetup";  
	 } 
	
	@RequestMapping("/foHomepage")  
	public String frontOffice()  
	{  
		return "foHomepage";  
	}
	
	@RequestMapping("/accountSummary")
	public String getAccountDetails(@RequestParam("acNo") int acNo, Model m) {
		Account acc = accountservice.getRecordById(acNo);
		m.addAttribute("acc", acc);
		return "viewAccountByacNo";
	}
	
	//*********Corporate Mapping Start*************
	
	
	
	
	@RequestMapping("/addCorporatee") 
	 public String addCorporateForm(Model m) 
	 { 
		 m.addAttribute("addCor", new Corporate()); 
		 return "addCorporateForm";  
	 } 
	
	@RequestMapping(value = "/addCorporate", method = RequestMethod.POST)
	public String addCorporate(Corporate cor) {
		int res = corporateservice.save(cor);
		if (res >= 1)
			return "redirect:/viewCorporates";
		else
			return "addcorporate-failure";
	}
	
	@RequestMapping("/viewCorporates")  
	public String viewCorporates(Model m)  
	{  
		List<Corporate> list=corporateservice.getAllRecords();  
	    m.addAttribute("list",list);    
		return "viewCorporates";  
	}
	
	@RequestMapping("/editCorporatee")
	public String getCorDetails(@RequestParam("c_id") int id, Model m) {
		Corporate c = corporateservice.getRecordById(id);
		m.addAttribute("cor", c);
		return "editCorporateForm";
	}
	
	@RequestMapping("/editCorporate")
	public String editCorporate(@ModelAttribute Corporate c) {
	    System.out.println(c);
	    if(corporateservice.update(c)>0)
	        return "redirect:/viewCorporates";
	    else
	        return "editCorporate-failure";
	}

	@RequestMapping("/deleteCorporate")  
	public String deleteCorporate(@RequestParam("c_id") int id)  
	{  
		int res=corporateservice.delete(id);
		if (res>=1)
			return "redirect:/viewCorporates";
		else
			return "deleteCorporate-failure";
	}
	
	//**********Corporate Mapping End**************
	
	//*********User Mappping Start ***************
	
	@RequestMapping("/viewUsers")  
	public String viewUsers(Model m)  
	{  
		List<User> list=userservice.getAllRecords();  
	    m.addAttribute("list",list);    
		return "viewUsers";  
	}
	
	@RequestMapping("/addUserr") 
	 public String addUserForm(Model m) 
	 { 
		List<Corporate> corList = corporateservice.getAllRecords();
		m.addAttribute("list",corList);
		 m.addAttribute("addUser", new User()); 
		 return "addUserForm";  
	 } 
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addUser(User u) {
		int res = userservice.save(u);
		if (res >= 1)
			return "redirect:/viewUsers";
		else
			return "adduser-failure";
	}
	
	@RequestMapping("/editUserr")
	public String getUserDetails(@RequestParam("u_id") int id, Model m) {
		User u = userservice.getRecordById(id);
		m.addAttribute("user", u);
		return "editUserForm";
	}
	
	@RequestMapping("/editUser")
	public String editUser(@ModelAttribute User u) {
	    System.out.println(u);
	    if(userservice.update(u)>0)
	        return "redirect:/viewUsers";
	    else
	        return "editUser-failure";
	}
	
	@RequestMapping("/deleteUser")  
	public String deleteUser(@RequestParam("u_id") int id)  
	{  
		int res=userservice.delete(id);
		if (res>=1)
			return "redirect:/viewUsers";
		else
			return "deleteUser-failure";
	}
	
	//********User Mapping end*****************
	
	//**********Account Mapping Start ***************
	
	@RequestMapping("/viewAccounts")  
	public String viewAccounts(Model m)  
	{  
		List<Account> list=accountservice.getAllRecords();  
	    m.addAttribute("list",list);    
		return "viewAccounts";  
	}
	
	@RequestMapping("/addAccountt") 
	 public String addAccountForm(Model m) 
	 { 
		List<Corporate> corList = corporateservice.getAllRecords();
		m.addAttribute("list",corList);
		 m.addAttribute("addAcc", new Account()); 
		 return "addAccountForm";  
	 } 
	
	@RequestMapping(value = "/addAccount", method = RequestMethod.POST)
	public String addAccount(Account acc) {
		int res = accountservice.save(acc);
		if (res >= 1)
			return "redirect:/viewAccounts";
		else
			return "addAccount-failure";
	}
	
	@RequestMapping("/deleteAccount")  
	public String deleteAccount(@RequestParam("acNo") int id)  
	{  
		int res=accountservice.delete(id);
		if (res>=1)
			return "redirect:/viewAccounts";
		else
			return "deleteAccount-failure";
	}
	
	//*************Account Mapping end*******************
	

}
