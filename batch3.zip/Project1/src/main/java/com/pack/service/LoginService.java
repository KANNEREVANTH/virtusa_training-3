package com.pack.service;

import java.util.List;

import com.pack.model.Login;

public interface LoginService {
	public Login getRecordById(int id);
	public boolean loginCheck(Login l);
	public boolean update(Login u);
	public List<Integer> getAllLoginIds();
	public boolean validateLoginId(int id);
}
