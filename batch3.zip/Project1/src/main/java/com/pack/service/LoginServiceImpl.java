package com.pack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Login;
import com.pack.repository.LoginDao;
import com.pack.repository.LoginRepository;

@Service("logService")
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	LoginRepository logRepository;

	@Override
	public Login getRecordById(int id) {
		// TODO Auto-generated method stub
		return logRepository.getRecordById(id);
	}

	@Override
	public boolean loginCheck(Login l) {
		// TODO Auto-generated method stub
		return logRepository.loginCheck(l);
	}

	@Override
	public boolean update(Login u) {
		// TODO Auto-generated method stub
		return logRepository.update(u);
	}

	@Override
	public List<Integer> getAllLoginIds() {
		// TODO Auto-generated method stub
		return logRepository.getAllLoginIds();
	}

	@Override
	public boolean validateLoginId(int id) {
		// TODO Auto-generated method stub
		return logRepository.validateLoginId(id);
	}
}
