package com.pack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Corporate;

import com.pack.repository.CorporateRepository;

@Service("corService")
public class CorporateServiceImpl implements CorporateService{
	
	@Autowired
	CorporateRepository correpo;

	@Override
	public int save(Corporate c) {
		// TODO Auto-generated method stub
		correpo.save(c);
		return 0;
	}

	@Override
	public int update(Corporate c) {
		// TODO Auto-generated method stub
		correpo.save(c);
		return 0;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		correpo.delete(id);
	 return id;
	}

	@Override
	public List<Corporate> getAllRecords() {
		// TODO Auto-generated method stub
		
		return correpo.findAll();
	}

	@Override
	public Corporate getRecordById(int id) {
		// TODO Auto-generated method stub
		return correpo.findById(id);
	}


}
