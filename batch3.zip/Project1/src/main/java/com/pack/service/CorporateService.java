package com.pack.service;


import java.util.List;


import com.pack.model.Corporate;

public interface CorporateService {
	
	 public int save(Corporate c);
	 public int update(Corporate c);
	 public int delete(int id);
	 public List<Corporate> getAllRecords();
	 public Corporate getRecordById(int id);
	
}
