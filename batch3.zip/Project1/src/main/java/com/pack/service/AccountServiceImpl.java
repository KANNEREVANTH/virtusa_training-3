package com.pack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Account;
import com.pack.repository.AccountRepository;

@Service("accService")
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	AccountRepository accrepository;

	@Override
	public int save(Account acc) {
		// TODO Auto-generated method stub
		return (int) accrepository.save(acc);
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		accrepository.delete(id);
		return id;
	}

	@Override
	public List<Account> getAllRecords() {
		// TODO Auto-generated method stub
		return accrepository.findAll();
	}

	@Override
	public Account getRecordById(long acNo) {
		// TODO Auto-generated method stub
		return ((AccountServiceImpl) accrepository).getRecordById(acNo);
	}
}
