package com.pack.service;

import java.util.List;

import com.pack.model.User;

public interface UserService {
	 public int save(User u);
	 public int update(User u);
	 public int delete(int id);
	 public List<User> getAllRecords();
	 public User getRecordById(int id);
}
