package com.pack.service;

import java.util.List;

import com.pack.model.Account;

public interface AccountService {
	public int save(Account acc);
	public int delete(int id);
	public List<Account> getAllRecords();
	public Account getRecordById(long acNo);
}
