package com.pack.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.User;
import com.pack.repository.UserDao;
import com.pack.repository.UserRepository;

@Service("userService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository repository;

	@Override
	public int save(User u) {
		// TODO Auto-generated method stub
		return (int) repository.save(u);
	}

	@Override
	public int update(User u) {
		// TODO Auto-generated method stub
		return (int) repository.save(u);
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		repository.delete(id);
		return id;
	}

	@Override
	public List<User> getAllRecords() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public User getRecordById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public  Optional<User> getRecordById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}*/
}
